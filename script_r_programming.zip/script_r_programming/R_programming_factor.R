
tingkat_pendidikan <- c("SD", "SMP", "SMP", "SMA", "SMA")

tingkat_pendidikan

factor_tingkat_pendidikan <- factor(tingkat_pendidikan)

factor_tingkat_pendidikan

levels(factor_tingkat_pendidikan)

factor(tingkat_pendidikan, ordered = T, levels=c("SD", "SMP", "SMA"))
