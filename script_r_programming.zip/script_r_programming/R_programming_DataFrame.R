#membuat data frame bmi 
bmi <- data.frame(
  gender = c("Female", "Male", "Female"),
  single = c(F, F, T),
  height = c(155, 170, 165.5),
  weight = c(64, 65, 48.5),
  age = c(42, 38, 26)
)