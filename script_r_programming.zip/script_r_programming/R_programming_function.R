function( arglist ) expr
    return(value)

pangkat <- function(a,b)
  return(a^b)


pangkat(2,3)
