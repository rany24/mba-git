my.array <- array(c(1:24), dim=c(4,3,2))

my.array

my.array[2,,]
my.array[2:3,,]
my.array[1:10]
my.array[1,2,2]

library(tidyverse)

h <- data.frame(a=c(1,2,3),b=c("Hello (World", "Hello (World", "hello (World"))
i <- h %>% separate(b, sep="\\(", c("c","d"))
