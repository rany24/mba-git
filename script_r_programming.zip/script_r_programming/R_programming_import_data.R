#Import data dari file csv
dki_csv <- read.csv("dkikepadatankelurahan2013.csv")

# Import data dari file xlsx 
# install.packages("readxl")
library(readxl)
excel_sheets("dkikepadatankelurahan2013.xlsx")

dki <- read_excel("dkikepadatankelurahan2013.xlsx")
dki_2 <-read_excel("dkikepadatankelurahan2013.xlsx", sheet = 2)
dki_jakarta_Selatan <- read_excel("dkikepadatankelurahan2013.xlsx", sheet = "Jakarta Selatan")

# Import data dari database (dalam hal ini MySQL) 
# Coba cari cara konek database postgresql dengan link berikut: https://db.rstudio.com/databases/postgresql/ 

#Step 1, install the RMySQL package (only if you did not install the package)
install.packages("RMySQL")


#Step 2, Establish a connection 
library(DBI)
con <- dbConnect(RMySQL::MySQL(), 
                 dbname = "tweater", 
                 host = "courses.csrrinzqubik.us-east-1.rds.amazonaws.com", 
                 port = 3306,
                 user = "student",
                 password = "datacamp")


#Step 3, List the database tables
tables <- dbListTables(con)
str(tables) #display structure of tables

#Step 4, Import data from a table
users <- dbReadTable(con,"users")
users #print users

tweats <- dbReadTable(con,"tweats")
tweats #print tweats

comments <- dbReadTable(con,"comments")
comments #print comments

#Step5, disconnect database 
dbDisconnect(con)



