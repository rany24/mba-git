my.matrix <- matrix(c(1:12), byrow = T, nrow=3)

my.matrix

ricis_official <- c(4.365, 565.183)
raditya_dika <- c(4.28, 541.246)
calon_sarjana <- c(4.191, 842.819)


# Membuat matrix dari ketiga vektor di atas 
matrix_youtuber_id <- matrix(c(ricis_official, 
                               raditya_dika, 
                               calon_sarjana), 
                             nrow=3,
                             byrow=TRUE 
                             )

matrix_youtuber_id


#Menamai Matrix 

parameter <- c("jumlah subscriber", "jumlah views")
youtuber <- c("ricis_official", "raditya_dika", "calon_sarjana")

#Menamai kolom di sebuah matrix 
colnames(matrix_youtuber_id) <- parameter

matrix_youtuber_id

#Menamai baris di sebuah matrix
rownames(matrix_youtuber_id) <- youtuber

matrix_youtuber_id

#Menghitung jumlah tiap kolom
colSums(matrix_youtuber_id)

#Menambahkan kolom jumlah video pada matrix 
jumlah_video <- c(290, 724, 552)

#Menggabungkan kolom jumlah video 
cbind(matrix_youtuber_id, jumlah_video)

#Menggabungkan baris 
atta_halilintar <- c(3.879, 267.432)

#Menggabungkan baris atta_halilintar 
rbind(matrix_youtuber_id, atta_halilintar)

matrix_youtuber_id[1,2]
matrix_youtuber_id[,2]

#aritmetika 

matrix_youtuber_id[,2] /matrix_youtuber_id[,1]
