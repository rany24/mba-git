# membuat vektor, matrix, data frme 
my_vector <- 1:20
my_matrix <- matrix(1:12, ncol=4)
my_df <- mtcars[1:10]

#membuat list 
my_list <- list(my_vector, my_matrix, my_df)

#melihat list 
my_list

#menyeleksi elemen dalam list
my_list[[1]]
my_list[[1]][7]
