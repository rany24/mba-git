# R base package 	base, utils, stats
# Reading data		readr, RODBC, foreign
# Data management 	plyr, dplyr, tidyr, reshape2, stringr, 	data.table
# Data viz		ggplot2, ggvis, ggmaps, leaflet
# Modeling		car, randomForest, rpart
# Timeseries		zoo, xts
# Work with web	jsonlite, httr, twitteR

install.packages("readr")

library(readr)
